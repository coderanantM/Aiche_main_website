from django.apps import AppConfig


class MainWebsiteConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'main_website'
